const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const { Server } = require('socket.io');

dotenv.config();
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

let multiplier = 1.00;
let interval;
let isRunning = false;
let crashPoint = 0;

const startGameLoop = () => {
  if (isRunning) return;
  isRunning = true;
  crashPoint = (Math.random() * 2 + 1).toFixed(2);
  multiplier = 1.00;

  interval = setInterval(() => {
    multiplier = (multiplier + 0.01).toFixed(2);
    io.emit('multiplierUpdate', multiplier);

    if (multiplier >= crashPoint) {
      io.emit('roundCrashed', crashPoint);
      clearInterval(interval);
      isRunning = false;
    }
  }, 100);
};

io.on('connection', (socket) => {
  console.log('User connected');

  socket.on('placeBet', (data) => {
    console.log('Bet Placed:', data);
    startGameLoop();
  });

  socket.on('cashOut', () => {
    io.emit('betResult', { status: 'cashed', multiplier });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

app.get('/', (req, res) => res.send('Crash Game Backend Running'));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));