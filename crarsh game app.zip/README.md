
# Crash Game – Real-Time Multiplayer Crypto Betting App

This is a full-stack **Crash Game** built with Node.js, Express, MongoDB, Socket.IO, and React.js. Players place crypto bets in real time as a multiplier increases — but if they don't cash out before the crash, they lose it all.

## Features

### Backend (Node.js + Express + MongoDB)
- REST API for player creation, balance fetch, and crypto conversion
- Real-time multiplier game loop with WebSockets (Socket.IO)
- USD to BTC/ETH conversion via CoinGecko API
- MongoDB stores user data, wallet balances, and transactions
- Crash point generated with randomness for fairness

### Frontend (React.js)
- Username login and wallet display
- Place bets and cash out in real time
- Live multiplier display via WebSocket
- Axios-based API communication
- Simple and responsive UI

## Technologies Used

| Layer      | Tech Stack                           |
|------------|---------------------------------------|
| Frontend   | React.js, Axios, Socket.IO Client     |
| Backend    | Node.js, Express.js, MongoDB, Socket.IO |
| Realtime   | WebSocket (Socket.IO)                 |
| Database   | MongoDB + Mongoose ORM                |
| API        | CoinGecko for live crypto rates       |

## How It Works

1. Create a player using the `CreatePlayer` form
2. Add USD to the wallet (default value)
3. Convert USD to BTC or ETH using real-time rates
4. Join a round by placing a crypto bet
5. Multiplier increases live
6. Cash out before crash to win, or lose the bet

## Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/crash-game.git
cd crash-game
```

### 2. Backend Setup

```bash
cd backend
npm install
```

Create `.env` file:

```
PORT=5000
MONGO_URI=your_mongodb_connection_string
```

Run the backend:

```bash
node server.js
```

### 3. Frontend Setup

```bash
cd frontend
npm install
```

(Optional) Create `.env` file:

```
REACT_APP_BACKEND_URL=http://localhost:5000
```

Run the frontend:

```bash
npm start
```

## API Endpoints

| Method | Endpoint                            | Description                        |
|--------|-------------------------------------|------------------------------------|
| POST   | `/api/player/create`                | Create a new player                |
| GET    | `/api/player/:username/balance`     | Get player wallet balances         |
| POST   | `/api/player/:username/convert`     | Convert USD to BTC/ETH             |
| GET    | `/api/player/:username/transactions`| Get player transaction history     |

## WebSocket Events

### Emitted by Client
- `placeBet`: Send bet details
- `cashOut`: Trigger early cash out

### Emitted by Server
- `multiplierUpdate`: Real-time multiplier values
- `roundCrashed`: Crash point announcement
- `betResult`: Win/Loss + payout info

## Screenshots

### Game Interface
![Game UI](./screenshots/game-ui.png)

### Multiplier in Action
![Multiplier](./screenshots/multiplier-update.png)

## Author

**Saswatika Sahu**  
MCA Graduate, ABA College, Odisha  
Email: saswatikasahu2000@gmail.com

## License

This project is for educational/demo purposes.
