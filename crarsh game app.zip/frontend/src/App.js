import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';
import axios from 'axios';

const socket = io('http://localhost:5000');

function App() {
  const [multiplier, setMultiplier] = useState(1.00);
  const [status, setStatus] = useState("Waiting...");

  useEffect(() => {
    socket.on('multiplierUpdate', (data) => setMultiplier(data));
    socket.on('roundCrashed', (data) => setStatus(`Crashed at ${data}x`));
    socket.on('betResult', (data) => setStatus(`Cashed out at ${data.multiplier}x`));
  }, []);

  const placeBet = () => {
    socket.emit('placeBet', { user: "Player1", amount: 0.01 });
    setStatus("Bet Placed");
  };

  const cashOut = () => {
    socket.emit('cashOut');
    setStatus("Cashout requested...");
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Crash Game</h1>
      <h2>Multiplier: {multiplier}x</h2>
      <p>Status: {status}</p>
      <button onClick={placeBet}>Place Bet</button>
      <button onClick={cashOut}>Cash Out</button>
    </div>
  );
}

export default App;